﻿using DreamPoeBot.Loki.Bot;

namespace FollowBot.SimpleEXtensions
{
    public interface ITaskManagerHolder
    {
        TaskManager GetTaskManager();
    }
}
